import React from 'react'
import ContactUs from '../../components/home/ContactUs'

function Contact() {
  return (
    <ContactUs />
  )
}

export default Contact